﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Web;
using System.Net.Mail;

namespace FlightsProj
{

    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();

            password.PasswordChar = '*';
            attachement_path.Text = @"E:\8 VS_Projects\FlightsProj\Flights.txt";
        }

        bool txt_flag = false; //Daca sa trimit prin gmail sau nu
        bool load_flag = true; //Daca sa afiseze "Loading..." sau nu
        static int i = 0; //Contorizeaza preturile
        string currency;


        //Inchide de pe Escape
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        //Daca bifeaza txt_checkbox
        private void txt_checkbox_CheckedChanged(object sender, EventArgs e)
        {
            txt_flag = true;
        }

        //Click pe Will Do!
        private void button1_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Ev_Will_Do!_Click");

            i = 0;

            timer1.Interval = (1000);
            timer1.Start();
        }



        private void timer1_Tick_1(object senderz, EventArgs ev)
        {
            webBrowser1.DocumentCompleted += WebBrowser1_DocumentCompleted3;

            timer1.Interval = (3600000);
            i = 0;

            webBrowser1.Navigate("https://www.google.com/");
            


            void WebBrowser1_DocumentCompleted3(object sender, WebBrowserDocumentCompletedEventArgs e)
            {
                Console.WriteLine("Ev_3");
                
                webBrowser1.DocumentCompleted -= WebBrowser1_DocumentCompleted3;
                webBrowser1.DocumentCompleted += WebBrowser1_DocumentCompleted4;

                //type_eSky
                HtmlElementCollection html_google_collection1 
                    = webBrowser1.Document.GetElementsByTagName("input");
                foreach (HtmlElement html_google_element1 in html_google_collection1)
                {
                    if (html_google_element1.GetAttribute("title").ToString() == "Search")
                    {
                        html_google_element1.InnerText = "eSky";
                        break;
                    }
                }

                //Click_Search
                HtmlElementCollection html_google_collection2 
                    = webBrowser1.Document.GetElementsByTagName("input");
                foreach (HtmlElement html_google_element2 in html_google_collection2)
                {
                    if (html_google_element2.GetAttribute("name").ToString() == "btnK")
                    {
                        html_google_element2.InvokeMember("Click");
                        break;
                    }
                }
            }



            //navigate_to_eSky
            void WebBrowser1_DocumentCompleted4(object sender, WebBrowserDocumentCompletedEventArgs e)
            {
                Console.WriteLine("Ev_4");
                
                webBrowser1.DocumentCompleted -= WebBrowser1_DocumentCompleted4;
                webBrowser1.DocumentCompleted += WebBrowser1_DocumentCompleted5;
                
                webBrowser1.Navigate("https://www.esky.ro/");
            }



            //Bifeaza RoundTrip
            void WebBrowser1_DocumentCompleted5(object sender, WebBrowserDocumentCompletedEventArgs e)
            {
                Console.WriteLine("Ev_5");
                
                webBrowser1.DocumentCompleted -= WebBrowser1_DocumentCompleted5;
                webBrowser1.DocumentCompleted += WebBrowser1_DocumentCompleted6;
                
                webBrowser1.Document.GetElementById("TripTypeRoundtrip").InvokeMember("Click");
            }



            //Citeste datele zborului
            void WebBrowser1_DocumentCompleted6(object sender, WebBrowserDocumentCompletedEventArgs e)
            {
                Console.WriteLine("Ev_6");
                
                webBrowser1.DocumentCompleted -= WebBrowser1_DocumentCompleted6;

                Timer timer_pt_6 = new Timer();
                timer_pt_6.Interval = (1000);
                timer_pt_6.Start();
                timer_pt_6.Tick += Timer_pt_6_Tick;
                
                webBrowser1.Document.GetElementById("departureOneway").InnerText = null;
                webBrowser1.Document.GetElementById("arrivalOneway").InnerText = null;
                webBrowser1.Document.GetElementById("departureDateOneway").InnerText = null;
                webBrowser1.Document.GetElementById("returnDateOneway").InnerText = null;
                
                void Timer_pt_6_Tick(object senders, EventArgs es)
                {
                    timer_pt_6.Tick -= Timer_pt_6_Tick;
                    timer_pt_6.Stop();

                    //Completeaza datele zborului din casutele formului
                    webBrowser1.Document.GetElementById("departureRoundtrip0").InnerText =
                            textBox1.Text;
                        webBrowser1.Document.GetElementById("arrivalRoundtrip0").InnerText =
                            textBox2.Text;
                        webBrowser1.Document.GetElementById("departureDateRoundtrip0").InnerText =
                            data_dus.Value.Date.ToString("yyyy-MM-dd");
                        webBrowser1.Document.GetElementById("departureDateRoundtrip1").InnerText =
                            data_retur.Value.Date.ToString("yyyy-MM-dd");

                    //Asa tarziu ca sa nu sara prematur la pasul 7
                    webBrowser1.DocumentCompleted += WebBrowser1_DocumentCompleted7;
                }  
            }


            //Da search pe eSky
            void WebBrowser1_DocumentCompleted7(object sender, WebBrowserDocumentCompletedEventArgs e)
            {
                Console.WriteLine("Ev_7");
                
                webBrowser1.DocumentCompleted -= WebBrowser1_DocumentCompleted7;
                webBrowser1.DocumentCompleted += WebBrowser1_DocumentCompleted;

                //Click_the_eSky_SEARCH_Button
                HtmlElementCollection html_eskybutton_collection
                    = webBrowser1.Document.GetElementsByTagName("button");
                foreach (HtmlElement html_eskybutton_element in html_eskybutton_collection)
                {
                    if (html_eskybutton_element.GetAttribute("type") == "submit")
                    {
                        html_eskybutton_element.InvokeMember("Click");
                        break;
                    }
                }
            }


             
            void WebBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
            {
                Console.WriteLine("Ev_Results");


                webBrowser1.DocumentCompleted -= WebBrowser1_DocumentCompleted;

                int nr_pages_check = 0; //Verific nr total de pagini doar o data
                int nr_pages = 2; //Pt a indeplini conditia ce-mi tine timerul mergand
                int current_page = 1;
                
                Timer timer_8 = new Timer();
                timer_8.Interval = (1000);
                timer_8.Start();

                timer_8.Tick += Timer_8_Tick;
                
                void Timer_8_Tick(object senderzz, EventArgs ez)
                {
                    //### LOAD RESULTS TEST ###
                    HtmlElementCollection html_results_ready
                       = webBrowser1.Document.GetElementsByTagName("span");
                    foreach (HtmlElement html_results_ready_elem in html_results_ready)
                    {
                        if (html_results_ready_elem.GetAttribute("data-tab-id").ToString() == "results")
                        {
                            load_flag = false;

                            //### TOTAL NR OF PAGES ###
                            if (nr_pages_check == 0)
                            {
                                ++nr_pages_check;

                                HtmlElementCollection html_nrpages
                                    = webBrowser1.Document.GetElementsByTagName("ul");
                                foreach (HtmlElement html_nrpages_elem in html_nrpages)
                                {
                                    if (html_nrpages_elem.GetAttribute("className").ToString() == "qa-number-of-all-pages")
                                    {
                                        nr_pages = Int32.Parse(html_nrpages_elem.GetAttribute("data-qa-number-of-all-pages"));
                                        break;
                                    }
                                }
                            }

                            Console.WriteLine("Current page: {0} / {1}", current_page, nr_pages);

                            //### CURRENCY ###
                            HtmlElementCollection html_eskyspan1_currency
                                = webBrowser1.Document.GetElementsByTagName("span");
                            foreach (HtmlElement html_eskyspan1_currencyelem in html_eskyspan1_currency)
                            {
                                if (html_eskyspan1_currencyelem.GetAttribute("className").ToString() == "current-price")
                                {
                                    HtmlElementCollection html_eskyspan2_currency
                                        = html_eskyspan1_currencyelem.Children;
                                    foreach (HtmlElement html_eskyspan2_currencyelem in html_eskyspan2_currency)
                                    {
                                        if (html_eskyspan2_currencyelem.GetAttribute("className").ToString() == "currency")
                                        {
                                            currency = html_eskyspan2_currencyelem.InnerText.ToString();
                                            break;
                                        }
                                    }
                                    break;
                                }
                            }



                            //### PRICE ###
                            MySqlCommand cmd6 = new MySqlCommand();

                            HtmlElementCollection html_eskyspan1_collection
                                = webBrowser1.Document.GetElementsByTagName("span");
                            foreach (HtmlElement html_eskyspan1_element in html_eskyspan1_collection)
                            {
                                if (html_eskyspan1_element.GetAttribute("className").ToString() == "current-price")
                                {
                                    HtmlElementCollection html_eskyspan2_collection
                                        = html_eskyspan1_element.Children;
                                    foreach (HtmlElement html_eskyspan2_element in html_eskyspan2_collection)
                                    {
                                        if (html_eskyspan2_element.GetAttribute("className").ToString() == "amount")
                                        {
                                            ++i;
                                            Console.WriteLine($"{i}.\t{textBox1.Text}-{textBox2.Text}\t{html_eskyspan2_element.InnerText.ToString()}\t{currency}");

                                            //WRITE IN DATA BASE
                                            /*
                                            using (MySqlConnection con = new MySqlConnection(
                                                        "server=localhost; user=root; password=Zamzoki2013; database=flights"))
                                            {
                                                con.Open();
                                                cmd6.Connection = con;

                                                cmd6.CommandText = "INSERT INTO vs_output(locatie_1, locatie_2, data_plecare, data_sosire, pret, moneda)" +
                                                " VALUES(@loc1, @loc2, @plecare, @sosire, @pret, @moneda)";
                                                //mysql_cmd.Parameters.AddWithValue("param_name", param_value); ## da o valoare parametrului
                                                cmd6.Parameters.AddWithValue("loc1", textBox1.Text);
                                                cmd6.Parameters.AddWithValue("loc2", textBox2.Text);
                                                cmd6.Parameters.AddWithValue("plecare", data_dus.Value.Date.ToString("yyyy-MM-dd"));
                                                cmd6.Parameters.AddWithValue("sosire", data_retur.Value.Date.ToString("yyyy-MM-dd"));
                                                cmd6.Parameters.AddWithValue("pret", html_eskyspan2_element.InnerText);
                                                cmd6.Parameters.AddWithValue("moneda", currency);

                                                cmd6.ExecuteNonQuery();

                                                cmd6.Parameters.Clear();
                                            }
                                            */
                                            if (i == 1)
                                            {
                                                using (StreamWriter flights_strw = new StreamWriter("E:\\8 VS_Projects\\FlightsProj\\Flights.txt"))
                                                    flights_strw.WriteLine($"{i}.\t{textBox1.Text}-{textBox2.Text}\t{html_eskyspan2_element.InnerText.ToString()}\t{currency}");
                                            }
                                            else
                                            {
                                                using (StreamWriter flights_strw = new StreamWriter("E:\\8 VS_Projects\\FlightsProj\\Flights.txt", append: true))
                                                    flights_strw.WriteLine($"{i}.\t{textBox1.Text}-{textBox2.Text}\t{html_eskyspan2_element.InnerText.ToString()}\t{currency}");
                                            }
                                           
                                        }
                                    }
                                }
                            }
                            //Am trecut preturile si moneda de pe pagina curenta


                            //###NEXT PAGE###
                            if (current_page < nr_pages)
                            {
                                HtmlElementCollection html_pages
                                = webBrowser1.Document.GetElementsByTagName("span");
                                foreach (HtmlElement html_page_elem in html_pages)
                                {
                                    if (html_page_elem.InnerText == "Următoarea pagină")
                                    {
                                        html_page_elem.InvokeMember("Click");
                                    }
                                }
                                ++current_page;
                                Console.WriteLine("");
                            }
                            else
                            {
                                timer_8.Stop();

                                if (txt_flag == true) //System.Web, System.Net.Mail
                                {
                                    //Overall
                                    MailMessage flights_msg =
                                        new MailMessage(from.Text, to.Text, "Flights", DateTime.Now.ToShortDateString() + "\t" + DateTime.Now.ToShortTimeString());
                                    SmtpClient smtpClient = new SmtpClient();
                                    smtpClient.Host = "smtp.gmail.com";
                                    smtpClient.UseDefaultCredentials = false;
                                    smtpClient.Credentials = new System.Net.NetworkCredential(from.Text, password.Text);
                                    smtpClient.Port = 587;
                                    smtpClient.EnableSsl = true;

                                    //Attachement
                                    Attachment flights_txt_file = new Attachment(attachement_path.Text);
                                    flights_msg.Attachments.Add(flights_txt_file);

                                    //Sending
                                    smtpClient.Send(flights_msg);
                                    MessageBox.Show("Mail Sent!", "", MessageBoxButtons.AbortRetryIgnore);

                                    flights_msg = null;
                                    smtpClient = null;
                                    flights_txt_file = null;
                                }
                            }
                                
                        }//de la testul care verifica daca rezultatele s-au incarcat complet
                    } //de la foreach ce cauta elem ce-mi indica ca rezultatele s-au incarcat complet 

                    if (load_flag)
                    {
                        Console.WriteLine("Loading...");
                        load_flag = false;
                    }

                } //timer_8 tick

                
            } //Last event

        }//timer 1 tick

        
    } //class_ending


    //DE REPARAT/ ADAUGAT
    //###DONE###        Sa pot schimba datele cautarii
    //###DONE###        Sa inchid de pe Esc
    //###DONE###        Sa verifice la un anumit interval de timp (o ora) preturile
    //###DONE###        Sa treaca rezultatele intr-o baza de date
    //###DONE###        Parametri in Query
    //###DONE###        Fara throw new UnimplementedException
    //###DONE###        Timer care sa astepte incarcarea paginii
    //###DONE###        Structura care sa dea pagina
    //###DONE###        Scoate data revenirii sau seteaza dus-intors!
    //###DONE###        Schimba data type in date, pune calendar pe form
    //###DONE###        Sa treaca rezultatele intr-un fisier txt
    //###DONE###        Sa trimita fisierul txt prin gmail


}
